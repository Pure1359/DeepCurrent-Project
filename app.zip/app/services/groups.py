from app.db_config import db_cursor

# Placeholder for now
# Create functions that have to do with groups
# Follow templates in users.py and auth.py
# Some Ideas:
# create_group
# add_account_to_group
# list_group_members
# remove_account_from_group
# get_group_id