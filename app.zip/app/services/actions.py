from app.db_config import db_cursor

# Placeholder for now
# Create functions that have to do with actions
# Follow templates in users.py and auth.py
# Some Ideas:
# log_action
# get_action_logs
# get_account_totals