from app.db_config import db_cursor

# Placeholder for now
# Create functions that have to do with stats
# Follow templates in users.py and auth.py
# Some Ideas:
# get_total_co2e_saved
# get_total_co2e_saved_by_travel
# get_total_co2e_saved_by_food
# get_total_co2e_saved_by_energy
# get_total_co2e_saved_by_waste