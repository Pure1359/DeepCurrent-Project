from app.db_config import db_cursor

# Placeholder for now
# Create functions that have to do with evidence
# Follow templates in users.py and auth.py
# Some Ideas:
# submit_evidence
# create_decision (admin deciding to approve or not)
# list_pending_evidence (list evidence that is awaiting admin approval)
# get_evidence_decisions